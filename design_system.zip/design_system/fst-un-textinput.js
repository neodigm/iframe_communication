let elTmpl = document.createElement("template")
elTmpl.innerHTML = `
<style>
    @import url('./unity-tokens.css');

    :host {}  /* Container Shadow Root */
    :host-context(unity-checkboxgroup) {} /* Ancestor */
    ::slotted( * ){}  /* target slotted content - applied before global css  */
</style>

<style>

.l-UnityTextInput .UnityTextInput {
  align-items: center;
  background-color: rgba(0,0,0,0);
  border-radius: var(--un-textinput-border-radius);
  box-sizing: border-box;
  color: var(--un-textinput-color-default);
  column-gap: var(--un-textinput-space-gap);
  display: inline-flex;
  font-family: var(--un-textinput-typography-font-family);
  font-size: var(--un-textinput-typography-font-size);
  font-weight: var(--un-textinput-typography-font-weight);
  height: calc(var(--un-textinput-input-space-vertical)*2 + var(--un-textinput-typography-line-height));
  letter-spacing: var(--un-textinput-typography-letter-spacing);
  line-height: var(--un-textinput-typography-line-height);
  min-width: 260px;
  padding: var(--un-textinput-space-vertical) var(--un-textinput-space-horizontal);
  position: relative;
}

.l-UnityTextInput .UnityTextInput_input {
  align-self: stretch;
  background: rgba(0,0,0,0);
  border: none;
  color: var(--un-textinput-color-default);
  flex: 1 1;
  font-family: var(--un-textinput-typography-font-family);
  font-size: var(--un-textinput-typography-font-size);
  font-weight: var(--un-textinput-typography-font-weight);
  font: inherit;
  letter-spacing: var(--un-textinput-typography-letter-spacing);
  line-height: var(--un-textinput-typography-line-height);
  outline: none;
  padding: var(--un-textinput-input-space-vertical) 0;
  text-overflow: ellipsis;
}

.l-UnityTextInput .UnityTextInput_slot {
  align-items: center;
  color: var(--un-textinput-color-placeholder-default);
  column-gap: var(--un-textinput-slot-space-gap);
  display: inline-flex;
  font-size: var(--un-textinput-typography-line-height);
  line-height: var(--un-textinput-typography-line-height);
}

.l-UnityTextInput .UnityTextInput_hidden:is(legend) {
  padding-inline-start: 0;
  padding-inline-end: 0;
}

.l-UnityTextInput [readonly='true'] {
  cursor: default;
}

.l-UnityTextInput [disabled='true'] {
  opacity: 0.4;
  pointer-events: none;
}

.l-UnityTextInput .UnityTextInput_fieldset {
  pointer-events: none;
  border-radius: inherit;
  overflow: hidden;
  min-width: 0%;
  background-color: rgba(0,0,0,0);
  margin-inline-start: 0;
  margin-inline-end: 0;
  position: absolute;
  bottom: 0;
  right: 0;
  left: 0;
  top: 0;
  border: var(--un-textinput-border-default-width) var(--un-textinput-border-default-style) var(--u-field-status-color, var(--un-textinput-border-default-color));
}

.l-UnityTextInput .UnitySpinner {
  display: inline-flex;
  color: var(--spinner-color, #666b7a);
}

.l-UnityTextInput .UnitySpinner_circular {
  position: relative;
  margin: 0;
  animation: UnitySpinner_rotate 1.4s linear infinite;
}

.l-UnityTextInput .UnitySpinner_circular .UnitySpinner_border {
  fill: none;
  stroke-dashoffset: 0;
  stroke-linecap: round;
}

.l-UnityTextInput .UnitySpinner_circular .UnitySpinner_path {
  animation: UnitySpinner_dash 1.4s ease-in-out infinite;
  fill: none;
  stroke-dasharray: 80px,200px;
  stroke-dashoffset: 0;
  stroke-linecap: square;
}

.hidden{
  display: none !important;
}

.UnityFieldFocus{
  border-color: var(--un-textinput-border-focus-color) !important;
}

@keyframes UnitySpinner_dash{
0% {
  stroke-dasharray: 1px,200px;
  stroke-dashoffset: 0px;
}

50% {
  stroke-dasharray: 100px,200px;
  stroke-dashoffset: -15px;
}
100% {
  stroke-dasharray: 100px 200px;
  stroke-dashoffset: -125px;
}
}

@keyframes UnitySpinner_rotate{
0% {
  transform: rotate(0deg);
}

100% {
  transform: rotate(360deg);
}
}

/*  AbbVie Core AMPM  */
[data-colorscheme='light'] .fst-un__core-color--text { color: var( --un-textinput-color-default );}
[data-colorscheme='light'] .fst-un__core-fill--svg   { fill: var(--un-textinput-color-placeholder-default);}
[data-colorscheme='dark']  .fst-un__core-color--text { color: var( --un-color-abbvie-white );}
[data-colorscheme='dark']  .fst-un__core-color--text::placeholder { color: var( --un-color-strong-gray-scale-50 );}
[data-colorscheme='dark']  .fst-un__core-fill--svg   { fill: var( --un-color-abbvie-white );}
[data-colorscheme='dark']  .fst-un__core-stroke--svg   { stroke: var( --un-color-abbvie-white );}

</style>

<output class="l-UnityTextInput">
 
  <label class="UnityTextInput" scale="small" data-colorscheme='light'
  part="textinput_toplevel">
    <span class="UnityTextInput_slot hidden" aria-hidden="true"
    part="textinput_searchicon">
      <svg xmlns="http://www.w3.org/2000/svg" class="fst-un__core-fill--svg" viewBox="0 0 512 512"
      style="width: var( --un-dimension-100 );"><path d="M505 442.7 405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"/></svg>
    </span>
    <input class="fst-un__core-color--text UnityTextInput_input" placeholder="" value="" part="textinput_field">
    <span class="UnityTextInput_slot hidden" part="textinput_spinner">
      <div aria-label="Loading..." aria-valuemin="0" aria-valuemax="100" role="progressbar" class="UnitySpinner">
        <svg class="UnitySpinner_circular fst-un__core-stroke--svg" viewBox="22 22 44 44" width="20" height="20">
          <circle class="UnitySpinner_border" stroke-width="3.6" cx="44" cy="44" r="20.2"></circle>
          <circle class="UnitySpinner_path" stroke="currentColor" stroke-width="3.24" cx="44" cy="44" r="20.2"></circle>
        </svg>
      </div>
    </span>
    <fieldset aria-hidden="true" class="UnityTextInput_fieldset" part="textinput_fieldset">
      <legend class="UnityTextInput_legend UnityTextInput_hidden"></legend>
    </fieldset>
  </label>

</output>
`

class UnityTextInput extends HTMLElement {
    constructor(){
      super()
      this.myShadow = this.attachShadow({mode: "closed"})
      this.isInit = false
      let clone = elTmpl.content.cloneNode( true )
      this.myShadow.append( clone )
    }
    static get observedAttributes(){  //  Allowed Attribs
      return [ "aria-busy", "aria-label", "colorscheme", "disabled", "placeholder", "readonly", "required", "scale", "search", "tabindex", "theme", "value" ]
    }
    get colorscheme(){ return this.getAttribute( "colorscheme" ) }
    set colorscheme( _colorscheme="light" ){ this.setAttribute( "colorscheme", _colorscheme )}

    attributeChangedCallback( _attrName, _orig, _new ){  //  Hareesh - this method fires whenever Vue updates this instance
      this.doInit()
      switch( _attrName.toLowerCase() ){
          case "colorscheme":
              this.elPartToplevel.dataset.colorscheme = _new;
          break;
      }
    }

    connectedCallback(){
      this.doInit();
      //for search icon 
      if(this.getAttribute("search") == "true"){
        this.elPartSearchIcon.classList.remove("hidden");
      }
      //for aria-busy
      if(this.getAttribute("aria-busy") == "true"){
        this.elPartLoader.classList.remove("hidden");
      }
      //for disabled attribute
      if(this.getAttribute("disabled") == "true"){
        this.elPartInputField.setAttribute("disabled", true);
      }
      //for placeholder attribute
      if(this.getAttribute("placeholder")){
        this.elPartInputField.placeholder = this.getAttribute("placeholder");
      }

      //for value attribute
      if(this.getAttribute("value")){
        this.elPartInputField.value = this.getAttribute("value");
      }

      //for readonly attribute
      if(this.getAttribute("readonly") == "true"){
        this.elPartInputField.setAttribute("readOnly", true);
      }

      //to highlight the input field when clicked/focused on textinput
      this.elPartInputField.addEventListener('focus', this._onFocus.bind( this ));
      this.elPartInputField.addEventListener('focusout', this._outFocus.bind( this ));
    }

    disconnectedCallback(){
      this.elPartInputField.removeEventListener('focus', this._onFocus);
      this.elPartInputField.removeEventListener('focusout', this._outFocus);
    }

    doInit(){  //  run once HMR (Hot Module Replacement)
      if( !this.isInit ){
        this.isInit = true
        
        this.elPartToplevel = this.myShadow.querySelector( "[part='textinput_toplevel']" )
        this.elPartSearchIcon = this.myShadow.querySelector( "[part='textinput_searchicon']" )
        this.elPartLoader = this.myShadow.querySelector( "[part='textinput_spinner']" )
        this.elPartInputField = this.myShadow.querySelector( "[part='textinput_field']" )
        this.elPartInputFieldset = this.myShadow.querySelector( "[part='textinput_fieldset']" )
      }
    }

    _onFocus(){
      this.elPartInputFieldset.classList.add("UnityFieldFocus");
    }
    _outFocus(){
      this.elPartInputFieldset.classList.remove("UnityFieldFocus");
    }
    
}

customElements.define( "fst-un-textinput", UnityTextInput )