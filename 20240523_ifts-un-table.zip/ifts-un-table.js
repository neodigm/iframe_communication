let elTmpl = document.createElement("template")
elTmpl.innerHTML = `
<style>
    @import url('./unity-tokens.css');

    :host {}  /* Container Shadow Root */
    :host-context(ifts-un-table) {} /* Ancestor */
    ::slotted( * ){ }  /* target slotted content - applied before global css  */
</style>

<style>

  .l-unityTable .UnityTable {

  }

  [data-colorscheme='light'] .fst-un__core-color--text { color: var( --un-checkbox-label-color );}
  [data-colorscheme='dark']  .fst-un__core-color--text { color: var( --un-color-abbvie-white );}

</style>

<output class="l-unityTable">

  <label class="UnityTable" data-colorscheme='light'
  part="table_toplevel">
    <span class="UnityTable__cntr" style="border: 0px; clip: rect(0px, 0px, 0px, 0px); height: 1px; margin: -1px; overflow: hidden; padding: 0px; position: absolute; white-space: nowrap; width: 1px;">
      <input type="checkbox" aria-checked="true"
      part="table_input">
    </span>
    <span data-checked="true" class="UnityTableCheck UnityTableCheck_interactive" 
    part="table_box">
      <span class="fst-un__core-bg" aria-hidden="true" style="display: block; width: 1em; height: 1em; pointer-events: none;">
        <svg xmlns="http://www.w3.org/2000/svg" 
        style="fill: #FFFFFF;" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7l233.4-233.3c12.5-12.5 32.8-12.5 45.3 0z"/></svg>
      </span>
    </span>
    <slot class="fst-un__core-color--text"
    part="table_label"></slot>
  </label>

</output>
`

class UnityTable extends HTMLElement {
    constructor(){
        super()
        this.myShadow = this.attachShadow({mode: "closed"})
        this.isInit = false
        this.elPartToplevel = null;

        let clone = elTmpl.content.cloneNode( true )
        this.myShadow.append( clone )
    }
    static get observedAttributes(){  //  Allowed Attribs
        return [ 'colorscheme' ]
    }
    get ariaChecked(){ return this.getAttribute( "aria-checked" ) }
    set ariaChecked( _ariaChecked ){ this.setAttribute( "aria-checked", _ariaChecked )}


    attributeChangedCallback( _attrName, _orig, _new ){
      this.doInit()
      switch( _attrName.toLowerCase() ){
          case "colorscheme":
              this.elPartToplevel.dataset.colorscheme = _new;
          break;
      }
    }
    connectedCallback(){
      this.doInit()

    }

    disconnectedCallback(){

    }

    doInit(){  //  run once HMR (Hot Module Replacement)
      if( !this.isInit ){
        this.isInit = true
        
        this.elPartToplevel = this.myShadow.querySelector( "[part='table_toplevel']" )
      }
    }
}

customElements.define( "ifts-un-table", UnityTable )


















const IFSTOpt = {}
const IFSTUtils = {}

class IFTSTable {
    constructor(_d, _aQ) {
        this._d = _d; this._aQ = _aQ;
        this.nTotal = 0
        this.bIsInit = false
        this.nRowHeight = 34  //  px
        this.fOnRowClick = []
    }
    init() {  //  rinit
      if( !this.bIsInit ){  //  once
        this._d[ IFSTOpt.N55_APP_STATE.CONTEXT ].addEventListener("click", ( ev ) => {
          let evAtr = IFSTUtils.walkDOM3( ev?.target, "IFTSTableRow", "returnEl" )  //  Return Element
          if( evAtr ) this.select( evAtr )
        }, false)
      }
      this.bIsInit = true
      return this;
    }
    render( sId, oRows ){
      if( this.bIsInit && sId ){
        let elPicn = this._d[ IFSTOpt.N55_APP_STATE.CONTEXT ].querySelector( this._aQ[0] + "#" + sId)
        if( elPicn && elPicn?.dataset?.iftsTableConfig ){
          this.nTotal = 0
          let oCnf = JSON.parse( elPicn.dataset.iftsTableConfig )
          let nRowCalc = ( oCnf.rowcount ) ? ( this.nRowHeight * oCnf.rowcount ) : ( this.nRowHeight * 12 )
          let sMU = `<header>`
          oCnf.cols.forEach( ( oCol )=>{ sMU += `<div>` + oCol.name + `</div>`})
          sMU += `</header>`
          if( oRows.rows.length ){
            sMU += `<output><article>`
            oRows.rows.forEach( ( aRow, nDx )=>{
              sMU += `<section data-n55-picnic-row="` + nDx + `">`
              aRow.forEach( ( sCell, nDx )=>{
                if( nDx <= (oCnf.cols.length - 1) ){
                  sMU += `<div>` + sCell + `</div>`  //  Has Header
                }else{
                  if( typeof sCell == "object" ){
                    sMU += `<aside data-n55-picnic-caption="` + sCell[0] + `">` + sCell[1] + `</aside>`
                  }else{ sMU += `<aside>` + sCell + `</aside>` }
                }
              } )
              sMU += `</section>`
              this.nTotal++
            } )
            sMU += `</article></output>`
          }
          elPicn.innerHTML = sMU
          if( IFSTOpt.ROOT ) IFSTOpt.ROOT.style.setProperty( "--neodigm-height-picnic", nRowCalc + "px")
          let elClickFirstRow = elPicn.querySelector("[data-n55-picnic-row]")
          if( elClickFirstRow ) this.select( elClickFirstRow )
        }
      }
      return this.nTotal;
    }
    select( elRow ){
      let elRowContr = elRow.parentElement
      if( elRowContr ){  //  Unselect prev  - TODO multiselect
        elRowContr = elRowContr.querySelector( "[data-ifts-table-select='true']" )
        if( elRowContr ) elRowContr.dataset.iftsTableSelect = "false"
        let elPicnic = IFSTUtils.walkDOM3( elRow.parentElement, "iftsTableConfig", "returnRoot" )  //  Return Element
        let _sId = elPicnic.id
        if(this.fOnRowClick[_sId]) this.fOnRowClick[_sId]( elRow )
        if(this.fOnRowClick["def"]) this.fOnRowClick["def"]( elRow )
        if( IFSTOpt.N55_GTM_DL_PICNIC ) IFSTUtils.doDataLayer( IFSTOpt.N55_GTM_DL_PICNIC, _sId )
      }
      elRow.dataset.iftsTableSelect = "true"
    }
    filter( sId, sSearch ){
      if( sId ){
        let elPicn = this._d.getElementById( sId )
        if( elPicn ){
          let elPicRows = elPicn.querySelectorAll( "output > article > section" )
          if( elPicRows ){
              this.nTotal = 0
              if( sSearch ){
              elPicRows.forEach( ( elRow )=>{
                if( elRow.innerHTML.toUpperCase().indexOf( sSearch.toUpperCase() ) == -1 ) {
                  elRow.classList.add( "h-filter-not-found" )
                }else{
                  elRow.classList.remove( "h-filter-not-found" )
                  this.nTotal++
                }
              } )
            }else{ elPicRows.forEach( ( elRow )=>{ elRow.classList.remove( "h-filter-not-found" ); this.nTotal++ } ) }
          }
        }
      }
      return this.nTotal;
    }
    setOnRowClick( _f, id="def" ){ this.fOnRowClick[ id ] = _f; return this; }
  }
  let neodigmPicnic = new IFTSTable( document, [".l-unityTable"] )






  :root {  /*  … And after a while, you can work on points for style  */
    --neodigm-theme-brand: #edba08;   --neodigm-theme-brand-alt: #915E00;  /* Custom Override */

    --neodigm-theme-primary: #92a8d1;   --neodigm-theme-primary-alt: #364C75;  /* Serenity approx. 25% darker */
    --neodigm-theme-secondary: #EDCED0; --neodigm-theme-secondary-alt: #978284;  /* Sand Dollar */
    --neodigm-theme-success: #009473;   --neodigm-theme-success-alt: #003817;  /* Emerald */
    --neodigm-theme-danger: #DD4124;    --neodigm-theme-danger-alt: #810000;  /* Tangerine Tango */
    --neodigm-theme-warning: #F5DF4D;   --neodigm-theme-warning-alt: #988200;  /* Illuminating */
    --neodigm-theme-info: #7BC4C4;      --neodigm-theme-info-alt: #1F6868;  /* Aqua Sky */
    --neodigm-theme-disabled: #d6d6d6;  --neodigm-theme-disabled-alt: #c6c6c6;  /* Light Gray */
    --neodigm-theme-night: #6a6a6a;     --neodigm-theme-night-alt: #242424;  /* Charcoal */
    --neodigm-theme-marcom: #B163A3;    --neodigm-theme-marcom-alt: #5F4B8B;  /* Radiant Orchid | Ultra Violet */
    --neodigm-theme-party: #FF6F61;     --neodigm-theme-party-alt: #C93F60;  /* Living Coral | Honeysuckle */

    --neodigm-height-picnic: calc( 44px * 3 )
}


/*  IFTSTable Begin  */
.l-unityTable {
  position: relative; display: block;
  border: solid 1px #ccc;
  margin: 2px; padding: 2px;
  height: var( --neodigm-height-picnic );
}
.l-unityTable > header {
  position: relative; display: grid;
  grid-template-columns: repeat( auto-fit, minmax( 96px, 1fr ) ) 9px ;
}
.l-unityTable div {
  border: solid 1px #ccc;
  font-size: .8em;
  margin: 2px; padding: 4px;
  overflow: hidden;
  position: relative;
  text-align: center;
  white-space: nowrap;
}
.l-unityTable output > article > section.h-filter-not-found { display: none; }
.l-unityTable > header > div {
  cursor: pointer; user-select: none;
}
.l-unityTable > output {
  position: relative; display: block;
  height: calc( var( --neodigm-height-picnic ) - 38px);
  overflow-y: scroll;
}
.l-unityTable > output > article {
  height: 100cqh;
  overflow-y: scroll;
}
.l-unityTable > output > article > section {
  position: relative; display: grid;
  grid-template-columns: repeat( auto-fit, minmax( 96px, 1fr ) );
}
.l-unityTable > output > article > section > aside { display: none; }
.l-unityTable[data-n55-theme='brand'] DIV{ border-color: var( --neodigm-theme-brand-alt )}
.l-unityTable[data-n55-theme='primary'] DIV{ border-color: var( --neodigm-theme-primary-alt )}
.l-unityTable[data-n55-theme='secondary'] DIV{ border-color: var( --neodigm-theme-secondary-alt )}
.l-unityTable[data-n55-theme='success'] DIV{ border-color: var( --neodigm-theme-success-alt )}
.l-unityTable[data-n55-theme='danger'] DIV{ border-color: var( --neodigm-theme-danger-alt )}
.l-unityTable[data-n55-theme='warning'] DIV{ border-color: var( --neodigm-theme-warning-alt )}
.l-unityTable[data-n55-theme='info'] DIV{ border-color: var( --neodigm-theme-info-alt )}
.l-unityTable[data-n55-theme='disabled'] DIV{ border-color: var( --neodigm-theme-disabled-alt )}
.l-unityTable[data-n55-theme='night'] DIV{ border-color: var( --neodigm-theme-night-alt )}
.l-unityTable[data-n55-theme='marcom'] DIV{ border-color: var( --neodigm-theme-marcom-alt )}
.l-unityTable[data-n55-theme='party'] DIV{ border-color: var( --neodigm-theme-party-alt )}

[data-n55-ampm-theme="light"] .l-unityTable > header > div { background-color: #eee }
[data-n55-ampm-theme="light"] .l-unityTable div { background-color: #fff }
[data-n55-ampm-theme="dark"]  .l-unityTable > header > div { background-color: var( --neodigm-theme-night-alt )}
[data-n55-ampm-theme="dark"]  .l-unityTable div { background-color: var( --neodigm-theme-night )}

[data-n55-ampm-theme="light"] .l-unityTable [data-ifts-table-select='true'] { background-color: var( --neodigm-theme-night ) }
[data-n55-ampm-theme="dark"]  .l-unityTable [data-ifts-table-select='true'] { background-color: var( --neodigm-theme-brand ) }

/*  IFTSTable End  */
  